﻿namespace TwitterFeed.Options
{
    public class MyOptions
    {
        public int Value { get; set; }
    }
}
