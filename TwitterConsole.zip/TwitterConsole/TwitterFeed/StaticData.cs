﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterFeed 
{
    public class StaticData : IStaticData
    {
        public StaticData()
        {
            DataQueue = new ConcurrentQueue<string>();
            Tweets = new List<TweetData>();
        }
        
        public ConcurrentQueue<string> DataQueue { get; set; }

        public IList<TweetData> Tweets { get; set; }

    }

    public interface IStaticData
    {
        ConcurrentQueue<string> DataQueue { get; set; }
        IList<TweetData> Tweets { get; set; }
    }
}
