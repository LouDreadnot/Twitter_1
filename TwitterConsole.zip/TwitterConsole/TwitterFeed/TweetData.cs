﻿using System;

namespace TwitterFeed
{
    public class Tweet
    {
        public TweetData Data { get; set; }
    }

    public class TweetData
    {
        private readonly DateTime _receivedDate;
        public TweetData()
        {
            _receivedDate = DateTime.Now;
        }
        public string Id { get; set; }
        public string Text { get; set; }
        public DateTime ReceivedDate { get { return _receivedDate; } }

    }
}
