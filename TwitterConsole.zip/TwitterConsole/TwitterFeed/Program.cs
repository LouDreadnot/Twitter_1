﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using TwitterFeed.Services;

// https://dev.to/krusty93/net-core-5-0-console-app-configuration-trick-and-tips-c1j

namespace TwitterFeed
{
    public class Program
    {
        public static async Task<int> Main(string[] args)
        {
            var host = CreateHostBuilder();

            await host.RunConsoleAsync();

            return Environment.ExitCode;
        }



        private static IHostBuilder CreateHostBuilder()
        {
            return Host.CreateDefaultBuilder()
                .ConfigureLogging(logging =>
                {
                    logging.ClearProviders();
                })
                .UseSerilog((hostContext, loggerConfiguration) =>
                {
                    loggerConfiguration.ReadFrom.Configuration(hostContext.Configuration);
                })
                .ConfigureServices(services =>
                {
                    services.AddScoped<ILiveFeed, LiveFeed>();
                    services.AddSingleton<IStaticData, StaticData>();
                    services.AddScoped<IQueueProcessorService, QueueProcessorService>();
                    services.AddHostedService<Worker>();
                });
        }


        public class Worker : IHostedService
        {
            private readonly string _configKey;
            private readonly ILogger<Worker> _logger;
            private readonly ILiveFeed _liveFeed;

            public Worker(IConfiguration configuration, ILogger<Worker> logger, ILiveFeed liveFeed)
            {
               // _myService = service ?? throw new ArgumentNullException(nameof(service));
                _logger = logger ?? throw new ArgumentNullException(nameof(logger));
                _configKey = configuration["ConfigKey"];
                _liveFeed = liveFeed;
            }

            public async Task StartAsync(CancellationToken cancellationToken)
            {
                _logger.LogInformation($"Read {_configKey} from settings");
                await _liveFeed.GetFeed();
            }

            public async Task StopAsync(CancellationToken cancellationToken)
            {
                throw new NotImplementedException();
            }
        }
    }
}
