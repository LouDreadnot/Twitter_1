﻿using Newtonsoft.Json;
using System.Threading.Tasks;

namespace TwitterFeed.Services
{
    public class QueueProcessorService : IQueueProcessorService
    {
        private readonly IStaticData _tempData;

        public QueueProcessorService(IStaticData tempData)
        {
            _tempData = tempData;
        }
        public void ProcessTweets()
        {
            var message = string.Empty;

            if (_tempData.DataQueue.TryDequeue(out message))
            {
                if (!string.IsNullOrWhiteSpace(message))
                {
                    var tweet = JsonConvert.DeserializeObject<Tweet>(message);
                   
                    if (tweet?.Data != null )
                        _tempData.Tweets.Add(tweet.Data);
                }
            }
        }

        public async Task PerformLongTaskAsync()
        {
            await Task.Delay(5000);
        }

        public int GetStats()
        {
            return _tempData.Tweets.Count;
        }

        public int GetQueuedMessagesCount() {
            return _tempData.DataQueue.Count;
        }
    }
}