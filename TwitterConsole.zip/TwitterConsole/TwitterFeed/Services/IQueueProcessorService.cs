﻿using System.Threading.Tasks;

namespace TwitterFeed.Services
{
    public interface IQueueProcessorService
    {
        void ProcessTweets();
        Task PerformLongTaskAsync();
        int GetStats();
        int GetQueuedMessagesCount();
    }
}