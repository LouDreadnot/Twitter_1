﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using TwitterFeed.Services;

namespace TwitterFeed
{
    public interface ILiveFeed
    {
        Task GetFeed();
    }
    public class LiveFeed : ILiveFeed
    {
        private readonly IStaticData _tempData;
        private readonly IQueueProcessorService _queueProcessorService;

        public LiveFeed(IStaticData staticData, IQueueProcessorService queueProcessorService)
        {
            _tempData = staticData;
            _queueProcessorService = queueProcessorService;
        }

        private Timer _timer = null;
        private Timer _processTimer = null;
        private int ctr = 0;

        private HttpClient GetApiClient()
        {
            var URL = new Uri(Environment.GetEnvironmentVariable("ApiUrl"));
            //string apiKey = Environment.GetEnvironmentVariable("ApiKey");
            //string apiSecret = Environment.GetEnvironmentVariable("ApiSecret");
            string bearerToken = Environment.GetEnvironmentVariable("BearerToken");

            var handler = new HttpClientHandler()
            {
                AllowAutoRedirect = false
            };

            HttpClient client = new HttpClient(handler);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
            //client.DefaultRequestHeaders.Add("ApiKey", apiKey);
            //client.DefaultRequestHeaders.Add("ApiSecret", apiSecret);
            client.BaseAddress = URL;

            return client;
        }

        public async Task GetFeed()
        {
            _processTimer = new Timer(ProcessTweets, null, 0, 10);
            _timer = new Timer(TimerCallback, null, 0, 60000);

            var client = GetApiClient();


            var stream = await client.GetStreamAsync(client.BaseAddress);

            while (true)
            {
                try
                {
                    using (var reader = new StreamReader(stream))
                    {
                        while (true)
                        {
                            var line = await reader.ReadLineAsync() + Environment.NewLine;

                            if (!string.IsNullOrWhiteSpace(line))
                            {
                                _tempData.DataQueue.Enqueue(line);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ex.Message.Remove(0, 1);
                    Console.Write("Stream ended");
                }
            }
        }

        private void ProcessTweets(Object obj)
        {
            if (_queueProcessorService.GetQueuedMessagesCount() > 101)
                Parallel.For(1, 100, inded => { _queueProcessorService.ProcessTweets(); });
        }

        private void TimerCallback(Object o)
        {
            if (ctr > 0)
            {
                var cnt = _queueProcessorService.GetStats();
                var tweetsPerMinute = cnt / ctr;

                Console.WriteLine($"{cnt.ToString()} Tweets processed");
                Console.WriteLine($"*** { tweetsPerMinute.ToString() } Tweets processed per minute");

                // these will be picked up on the next iteration
                Console.WriteLine($" messages in queue: {_queueProcessorService.GetQueuedMessagesCount()}");
                Console.WriteLine();
            }
            else
            {
                Console.Write("Processing Tweets .................." + Environment.NewLine);
                Console.WriteLine();
            }
            ctr += 1;
        }
    }
}
